/*
   Metodos Utiles con Bits
*/

/* Retorna el siguiente entero con igual cantidad de bits encendidos */
uint next_popcount(uint n){
    uint c = (n & -n);
    uint r = n + c;
    return (((r ^ n) >> 2) / c) | r;
}

/* Retorna el primer entero con n bits encendidos */
uint init_popcount(int n){
    return (1 << n) - 1;
}
