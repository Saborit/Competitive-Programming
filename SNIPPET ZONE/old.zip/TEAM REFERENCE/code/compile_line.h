g++ -std=c++17 -Wshadow -Wall -o %e %f -fsanitize=address -fsanitize=undefined -D_GLIBCXX_DEBUG -g
